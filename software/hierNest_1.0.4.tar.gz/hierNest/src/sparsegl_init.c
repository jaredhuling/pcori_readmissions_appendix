#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <Rmath.h>
#include <R_ext/Rdynload.h>
#include <R_ext/RS.h>



#define FDEF(name){#name, (DL_FUNC) &F77_SUB(name), sizeof(name ## _t)/sizeof(name ## _t[0]), name ##_t}

/* -------------------------------------------------------------------------- */
/* sparse_four                                                                */
/* -------------------------------------------------------------------------- */
void F77_NAME(sparse_four)(
    int *bn,
    int *bs,
    int *ix,
    int *iy,
    double *gam,
    int *nobs,
    int *nvars,
    double *x,
    double *y,
    double *pf,
    double *pfl1,
    int *dfmax,
    int *pmax,
    int *nlam,
    double *flmin,
    double *ulam,
    double *eps,
    int *maxit,
    int *intr,
    int *nalam,
    double *b0,
    double *beta,
    int *activeGroup,
    int *nbeta,
    double *alam,
    int *npass,
    int *jerr,
    double *mse,
    double *alsparse1,
    double *alsparse2,
    double *lb,
    double *ub,
    int *cn,
    int *drgix,
    int *drgiy,
    int *cn_s,
    int *cn_e
);

static R_NativePrimitiveArgType sparse_four_t[] = {
  INTSXP,   /* bn */
  INTSXP,   /* bs */
  INTSXP,   /* ix */
  INTSXP,   /* iy */
  REALSXP,  /* gam */
  INTSXP,   /* nobs */
  INTSXP,   /* nvars */
  REALSXP,  /* x */
  REALSXP,  /* y */
  REALSXP,  /* pf */
  REALSXP,  /* pfl1 */
  INTSXP,   /* dfmax */
  INTSXP,   /* pmax */
  INTSXP,   /* nlam */
  REALSXP,  /* flmin */
  REALSXP,  /* ulam */
  REALSXP,  /* eps */
  INTSXP,   /* maxit */
  INTSXP,   /* intr */
  INTSXP,   /* nalam */
  REALSXP,  /* b0 */
  REALSXP,  /* beta */
  INTSXP,   /* activeGroup */
  INTSXP,   /* nbeta */
  REALSXP,  /* alam */
  INTSXP,   /* npass */
  INTSXP,   /* jerr */
  REALSXP,  /* mse */
  REALSXP,  /* alsparse1 */
  REALSXP,  /* alsparse2 */
  REALSXP,  /* lb */
  REALSXP,  /* ub */
  INTSXP,   /* cn */
  INTSXP,   /* drgix */
  INTSXP,   /* drgiy */
  INTSXP,   /* cn_s */
  INTSXP    /* cn_e */
};

/* -------------------------------------------------------------------------- */
/* spmat_four                                                                 */
/* -------------------------------------------------------------------------- */
void F77_NAME(spmat_four)(
    int *bn,
    int *bs,
    int *ix,
    int *iy,
    double *gam,
    int *nobs,
    int *nvars,
    double *x,
    int *xidx,
    int *xcptr,
    int *nnz,
    double *y,
    double *pf,
    double *pfl1,
    int *dfmax,
    int *pmax,
    int *nlam,
    double *flmin,
    double *ulam,
    double *eps,
    int *maxit,
    int *intr,
    int *nalam,
    double *b0,
    double *beta,
    int *activeGroup,
    int *nbeta,
    double *alam,
    int *npass,
    int *jerr,
    double *mse,
    double *alsparse1,
    double *alsparse2,
    double *lb,
    double *ub,
    int *cn,
    int *drgix,
    int *drgiy,
    int *cn_s,
    int *cn_e
);

static R_NativePrimitiveArgType spmat_four_t[] = {
  INTSXP,   /* bn */
  INTSXP,   /* bs */
  INTSXP,   /* ix */
  INTSXP,   /* iy */
  REALSXP,  /* gam */
  INTSXP,   /* nobs */
  INTSXP,   /* nvars */
  REALSXP,  /* x */
  INTSXP,   /* xidx */
  INTSXP,   /* xcptr */
  INTSXP,   /* nnz */
  REALSXP,  /* y */
  REALSXP,  /* pf */
  REALSXP,  /* pfl1 */
  INTSXP,   /* dfmax */
  INTSXP,   /* pmax */
  INTSXP,   /* nlam */
  REALSXP,  /* flmin */
  REALSXP,  /* ulam */
  REALSXP,  /* eps */
  INTSXP,   /* maxit */
  INTSXP,   /* intr */
  INTSXP,   /* nalam */
  REALSXP,  /* b0 */
  REALSXP,  /* beta */
  INTSXP,   /* activeGroup */
  INTSXP,   /* nbeta */
  REALSXP,  /* alam */
  INTSXP,   /* npass */
  INTSXP,   /* jerr */
  REALSXP,  /* mse */
  REALSXP,  /* alsparse1 */
  REALSXP,  /* alsparse2 */
  REALSXP,  /* lb */
  REALSXP,  /* ub */
  INTSXP,   /* cn */
  INTSXP,   /* drgix */
  INTSXP,   /* drgiy */
  INTSXP,   /* cn_s */
  INTSXP    /* cn_e */
};

/* -------------------------------------------------------------------------- */
/* log_sparse_four                                                            */
/* -------------------------------------------------------------------------- */
void F77_NAME(log_sparse_four)(
    int *bn,
    int *bs,
    int *ix,
    int *iy,
    double *gam,
    int *nobs,
    int *nvars,
    double *x,
    double *y,
    double *pf,
    double *pfl1,
    int *dfmax,
    int *pmax,
    int *nlam,
    double *flmin,
    double *ulam,
    double *eps,
    int *maxit,
    int *intr,
    int *nalam,
    double *b0,
    double *beta,
    int *activeGroup,
    int *nbeta,
    double *alam,
    int *npass,
    int *jerr,
    double *alsparse1,
    double *alsparse2,
    double *lb,
    double *ub,
    int *cn,
    int *drgix,
    int *drgiy,
    int *cn_s,
    int *cn_e
);

static R_NativePrimitiveArgType log_sparse_four_t[] = {
  INTSXP,   /* bn */
  INTSXP,   /* bs */
  INTSXP,   /* ix */
  INTSXP,   /* iy */
  REALSXP,  /* gam */
  INTSXP,   /* nobs */
  INTSXP,   /* nvars */
  REALSXP,  /* x */
  REALSXP,  /* y */
  REALSXP,  /* pf */
  REALSXP,  /* pfl1 */
  INTSXP,   /* dfmax */
  INTSXP,   /* pmax */
  INTSXP,   /* nlam */
  REALSXP,  /* flmin */
  REALSXP,  /* ulam */
  REALSXP,  /* eps */
  INTSXP,   /* maxit */
  INTSXP,   /* intr */
  INTSXP,   /* nalam */
  REALSXP,  /* b0 */
  REALSXP,  /* beta */
  INTSXP,   /* activeGroup */
  INTSXP,   /* nbeta */
  REALSXP,  /* alam */
  INTSXP,   /* npass */
  INTSXP,   /* jerr */
  REALSXP,  /* alsparse1 */
  REALSXP,  /* alsparse2 */
  REALSXP,  /* lb */
  REALSXP,  /* ub */
  INTSXP,   /* cn */
  INTSXP,   /* drgix */
  INTSXP,   /* drgiy */
  INTSXP,   /* cn_s */
  INTSXP    /* cn_e */
};

/* -------------------------------------------------------------------------- */
/* log_spmat_four                                                             */
/* -------------------------------------------------------------------------- */
void F77_NAME(log_spmat_four)(
    int *bn,
    int *bs,
    int *ix,
    int *iy,
    double *gam,
    int *nobs,
    int *nvars,
    double *x,
    int *xidx,
    int *xcptr,
    int *nnz,
    double *y,
    double *pf,
    double *pfl1,
    int *dfmax,
    int *pmax,
    int *nlam,
    double *flmin,
    double *ulam,
    double *eps,
    int *maxit,
    int *intr,
    int *nalam,
    double *b0,
    double *beta,
    int *activeGroup,
    int *nbeta,
    double *alam,
    int *npass,
    int *jerr,
    double *alsparse1,
    double *alsparse2,
    double *lb,
    double *ub,
    int *cn,
    int *drgix,
    int *drgiy,
    int *cn_s,
    int *cn_e
);

static R_NativePrimitiveArgType log_spmat_four_t[] = {
  INTSXP,   /* bn */
  INTSXP,   /* bs */
  INTSXP,   /* ix */
  INTSXP,   /* iy */
  REALSXP,  /* gam */
  INTSXP,   /* nobs */
  INTSXP,   /* nvars */
  REALSXP,  /* x */
  INTSXP,   /* xidx */
  INTSXP,   /* xcptr */
  INTSXP,   /* nnz */
  REALSXP,  /* y */
  REALSXP,  /* pf */
  REALSXP,  /* pfl1 */
  INTSXP,   /* dfmax */
  INTSXP,   /* pmax */
  INTSXP,   /* nlam */
  REALSXP,  /* flmin */
  REALSXP,  /* ulam */
  REALSXP,  /* eps */
  INTSXP,   /* maxit */
  INTSXP,   /* intr */
  INTSXP,   /* nalam */
  REALSXP,  /* b0 */
  REALSXP,  /* beta */
  INTSXP,   /* activeGroup */
  INTSXP,   /* nbeta */
  REALSXP,  /* alam */
  INTSXP,   /* npass */
  INTSXP,   /* jerr */
  REALSXP,  /* alsparse1 */
  REALSXP,  /* alsparse2 */
  REALSXP,  /* lb */
  REALSXP,  /* ub */
  INTSXP,   /* cn */
  INTSXP,   /* drgix */
  INTSXP,   /* drgiy */
  INTSXP,   /* cn_s */
  INTSXP    /* cn_e */
};

/* -------------------------------------------------------------------------- */
/* wsgl                                                                       */
/* -------------------------------------------------------------------------- */
void F77_NAME(wsgl)(
  int *bn,
  int *bs,
  int *ix,
  int *iy,
  double *gam,
  int *nobs,
  int *nvars,
  double *x,
  double *r,
  double *pf,
  double *pfl1,
  int *pmax,
  double *ulam,
  double *eps,
  int *maxit,
  int *intr,
  double *b0,
  double *beta,
  int *activeGroup,
  int *activeGroupIndex,
  int *ni,
  int *npass,
  int *jerr,
  double *alsparse1,
  double *alsparse2,
  double *lb,
  double *ub,
  int *sset,
  int *eset,
  double *b0old,
  double *betaold,
  double *al0,
  int *findlambda,
  int *l,
  int *me,
  int *cn
);

static R_NativePrimitiveArgType wsgl_t[] = {
  INTSXP,   /* bn */
  INTSXP,   /* bs */
  INTSXP,   /* ix */
  INTSXP,   /* iy */
  REALSXP,  /* gam */
  INTSXP,   /* nobs */
  INTSXP,   /* nvars */
  REALSXP,  /* x */
  REALSXP,  /* r */
  REALSXP,  /* pf */
  REALSXP,  /* pfl1 */
  INTSXP,   /* pmax */
  REALSXP,  /* ulam */
  REALSXP,  /* eps */
  INTSXP,   /* maxit */
  INTSXP,   /* intr */
  REALSXP,  /* b0 */
  REALSXP,  /* beta */
  INTSXP,   /* activeGroup */
  INTSXP,   /* activeGroupIndex */
  INTSXP,   /* ni */
  INTSXP,   /* npass */
  INTSXP,   /* jerr */
  REALSXP,  /* alsparse1 */
  REALSXP,  /* alsparse2 */
  REALSXP,  /* lb */
  REALSXP,  /* ub */
  INTSXP,   /* sset */
  INTSXP,   /* eset */
  REALSXP,  /* b0old */
  REALSXP,  /* betaold */
  REALSXP,  /* al0 */
  INTSXP,   /* findlambda */
  INTSXP,   /* l */
  INTSXP,   /* me */
  INTSXP    /* cn */
};

/* -------------------------------------------------------------------------- */
/* spmat_wsgl                                                                 */
/* -------------------------------------------------------------------------- */
void F77_NAME(spmat_wsgl)(
  int *bn,
  int *bs,
  int *ix,
  int *iy,
  double *gam,
  int *nobs,
  int *nvars,
  double *x,
  int *xidx,
  int *xcptr,
  int *nnz,
  double *r,
  double *pf,
  double *pfl1,
  int *pmax,
  double *ulam,
  double *eps,
  int *maxit,
  int *intr,
  double *b0,
  double *beta,
  int *activeGroup,
  int *activeGroupIndex,
  int *ni,
  int *npass,
  int *jerr,
  double *alsparse1,
  double *alsparse2,
  double *lb,
  double *ub,
  int *sset,
  int *eset,
  double *b0old,
  double *betaold,
  double *al0,
  int *findlambda,
  int *l,
  int *me,
  int *cn
);

static R_NativePrimitiveArgType spmat_wsgl_t[] = {
  INTSXP,   /* bn */
  INTSXP,   /* bs */
  INTSXP,   /* ix */
  INTSXP,   /* iy */
  REALSXP,  /* gam */
  INTSXP,   /* nobs */
  INTSXP,   /* nvars */
  REALSXP,  /* x */
  INTSXP,   /* xidx */
  INTSXP,   /* xcptr */
  INTSXP,   /* nnz */
  REALSXP,  /* r */
  REALSXP,  /* pf */
  REALSXP,  /* pfl1 */
  INTSXP,   /* pmax */
  REALSXP,  /* ulam */
  REALSXP,  /* eps */
  INTSXP,   /* maxit */
  INTSXP,   /* intr */
  REALSXP,  /* b0 */
  REALSXP,  /* beta */
  INTSXP,   /* activeGroup */
  INTSXP,   /* activeGroupIndex */
  INTSXP,   /* ni */
  INTSXP,   /* npass */
  INTSXP,   /* jerr */
  REALSXP,  /* alsparse1 */
  REALSXP,  /* alsparse2 */
  REALSXP,  /* lb */
  REALSXP,  /* ub */
  INTSXP,   /* sset */
  INTSXP,   /* eset */
  REALSXP,  /* b0old */
  REALSXP,  /* betaold */
  REALSXP,  /* al0 */
  INTSXP,   /* findlambda */
  INTSXP,   /* l */
  INTSXP,   /* me */
  INTSXP    /* cn */
};




static R_FortranMethodDef fMethods[] = {
  FDEF(sparse_four) ,
  FDEF(spmat_four) ,
  FDEF(log_sparse_four) ,
  FDEF(log_spmat_four) ,
  FDEF(wsgl) ,
  FDEF(spmat_wsgl) ,
  {NULL, NULL, 0}
};

void R_init_sparsegl(DllInfo *dll){
  R_registerRoutines(dll, NULL, NULL, fMethods, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
