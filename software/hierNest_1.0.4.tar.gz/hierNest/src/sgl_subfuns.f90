MODULE sgl_subfuns

   USE spmatmul
   IMPLICIT NONE

   CONTAINS

   ! -----------------------------------------------------------------------
   ! Screening / KKT statistic for one predictor block of the hierNest
   ! penalty  lambda*pf*||theta||_2 + lambda*alpha1*pf*sum_M ||theta^M||_2
   !          + lambda*alpha2*sum_i pfl1_i*|theta_i|
   ! (the first element of the block, the common effect, carries no l1
   ! penalty). On entry s holds the block gradient; on exit s holds the
   ! thresholded gradient and snorm = ||s||_2, to be compared with
   ! pf*lambda (KKT check) or pf*(2*lam_r - lam_{r-1}) (sequential strong
   ! rule). Coordinates are first soft-thresholded at level lama3
   ! (= lambda*alpha2); each sub-block is then either linearized at the
   ! current nonzero coefficients (level lama2 = lambda*alpha1, using
   ! absolute values) or, when the sub-block coefficients are all zero,
   ! group-soft-thresholded exactly. This is well-defined for fully
   ! inactive blocks, which the previous theta_tilt construction (0/0)
   ! was not.
   SUBROUTINE hier_block_stat(bsg, s, pfl1g, bg, lama2, lama3, pfg, &
         startdrg, enddrg, cn, drgix, drgiy, startix, snorm)
      IMPLICIT NONE
      INTEGER, INTENT(in) :: bsg, startdrg, enddrg, cn, startix
      INTEGER, INTENT(in) :: drgix(cn), drgiy(cn)
      DOUBLE PRECISION, INTENT(inout) :: s(bsg)
      DOUBLE PRECISION, INTENT(in) :: pfl1g(bsg), bg(bsg)
      DOUBLE PRECISION, INTENT(in) :: lama2, lama3, pfg
      DOUBLE PRECISION, INTENT(out) :: snorm
      INTEGER :: i, j, i1, i2
      DOUBLE PRECISION :: bnorm, gnorm
      DO i = 2, bsg
         s(i) = SIGN(MAX(ABS(s(i)) - lama3 * pfl1g(i), 0.0D0), s(i))
      ENDDO
      DO j = startdrg, enddrg
         i1 = drgix(j) - startix + 1
         i2 = drgiy(j) - startix + 1
         bnorm = SQRT(DOT_PRODUCT(bg(i1:i2), bg(i1:i2)))
         IF (bnorm > 0.0D0) THEN
            DO i = i1, i2
               s(i) = SIGN(MAX(ABS(s(i)) - lama2 * pfg * ABS(bg(i)) / bnorm, 0.0D0), s(i))
            ENDDO
         ELSE
            gnorm = SQRT(DOT_PRODUCT(s(i1:i2), s(i1:i2)))
            IF (gnorm > lama2 * pfg) THEN
               s(i1:i2) = s(i1:i2) * (gnorm - lama2 * pfg) / gnorm
            ELSE
               s(i1:i2) = 0.0D0
            ENDIF
         ENDIF
      ENDDO
      snorm = SQRT(DOT_PRODUCT(s, s))
      RETURN
   END SUBROUTINE hier_block_stat


   SUBROUTINE strong_rule (is_in_E_set, ga, pf, tlam)
      IMPLICIT NONE
      INTEGER :: g, k
      INTEGER, DIMENSION (:), INTENT(inout) :: is_in_E_set
      DOUBLE PRECISION, DIMENSION (:), INTENT(in) :: ga
      DOUBLE PRECISION, DIMENSION (:), INTENT(in) :: pf
      DOUBLE PRECISION, INTENT(in) :: tlam
      DOUBLE PRECISION :: z
      k = SIZE(is_in_E_set)
      !z = tlam * (1 - alsparse)
      z = tlam
      DO g = 1, k
         IF (is_in_E_set(g) .EQ. 1) CYCLE
         IF (ga(g) > pf(g) * z) is_in_E_set(g) = 1
      ENDDO
      RETURN
   END SUBROUTINE strong_rule

   SUBROUTINE kkt_check(is_in_E_set, violation, bn, ix, iy, vl, pf,pfl1, bs, lama1,&
   lama2,lama3, ga, nvars,drgix,drgiy,cn,cn_s,cn_e,b)
      IMPLICIT NONE
      INTEGER :: g, startix, endix, nvars
      INTEGER, INTENT(in) :: bn
      INTEGER, INTENT(in) :: bs(bn)
      INTEGER, INTENT(in) :: ix(bn), iy(bn)
      INTEGER, DIMENSION(:), INTENT(inout) :: is_in_E_set
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: ga
      DOUBLE PRECISION, DIMENSION (:), INTENT(in) :: vl
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: s
      DOUBLE PRECISION :: snorm
      DOUBLE PRECISION, INTENT(in) :: pf(bn)
      DOUBLE PRECISION, INTENT(in) :: pfl1(nvars)
      INTEGER, INTENT(inout) :: violation
      DOUBLE PRECISION, INTENT(in) :: lama1,lama2,lama3
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: theta_tilt
      INTEGER:: startdrg, enddrg, drginx, drgstartinx, drgendinx, theta_tilt_start, theta_tilt_end
      DOUBLE PRECISION :: theta_drg_norm
      INTEGER:: cn
      INTEGER:: drgix(cn)
      INTEGER:: drgiy(cn)
      INTEGER:: cn_s(bn)
      INTEGER:: cn_e(bn),drginxsub
      DOUBLE PRECISION, DIMENSION (0:nvars), INTENT(in) :: b
            
      DO g = 1, bn
         IF (is_in_E_set(g) .EQ. 1) CYCLE
         startix = ix(g)
         endix = iy(g)
         
         ALLOCATE(s(bs(g)))
         s = vl(startix:endix)
         CALL hier_block_stat(bs(g), s, pfl1(startix:endix), b(startix:endix), &
              lama2, lama3, pf(g), cn_s(g), cn_e(g), cn, drgix, drgiy, startix, snorm)
         ga(g) = snorm
         IF(ga(g) > pf(g)*lama1 ) THEN
            is_in_E_set(g) = 1
            violation = 1
         ENDIF
         DEALLOCATE(s)
      ENDDO
      RETURN
   END SUBROUTINE kkt_check


   SUBROUTINE update_step(bsg, startix, endix, b, lama1,lama2,lama3, t_for_sg, pfg, pfl1, x,&
         isDifZero, nobs, r, gamg, maxDif,nvars, lb, ub, startsubgp, endsubgp, drgix, drgiy,drgdim)
      IMPLICIT NONE
      INTEGER, INTENT(in) :: bsg, nobs, nvars
      INTEGER, INTENT(in) :: startix, endix
      DOUBLE PRECISION :: gamg
      DOUBLE PRECISION, INTENT(inout) :: maxDif
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: oldb, s, dd
      DOUBLE PRECISION, DIMENSION (0:nvars), INTENT(inout) :: b
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: r
      DOUBLE PRECISION :: snorm, tea
      DOUBLE PRECISION, INTENT(in) :: lama1,lama2,lama3, t_for_sg, pfg, lb, ub
      DOUBLE PRECISION, INTENT(in) :: pfl1(bsg)
      DOUBLE PRECISION, DIMENSION (:), INTENT(in) :: x(nobs,nvars)
      INTEGER, INTENT(inout) :: isDifZero
      INTEGER :: k
      INTEGER :: i
      INTEGER :: subgp_ix, subgp_iy
      INTEGER, INTENT(in) :: startsubgp, endsubgp, drgdim
      INTEGER, INTENT(in) :: drgix(drgdim),drgiy(drgdim)
      INTEGER :: s_endinx


      ALLOCATE(s(bsg))
      ALLOCATE(oldb(bsg))
      isDifZero = 0
      oldb = b(startix:endix)
      s = MATMUL(r, x(:, startix:endix))/nobs
      s = s*t_for_sg + b(startix:endix)
      
      s_endinx = endix-startix+1
      CALL softthresh(s(2:s_endinx), lama3*t_for_sg*pfl1(2:bsg), bsg-1)
      
      DO i = startsubgp, endsubgp
      subgp_ix = drgix(i) - drgix(startsubgp) +2
      subgp_iy = drgiy(i) - drgix(startsubgp) +2
      snorm = SQRT(DOT_PRODUCT(s(subgp_ix: subgp_iy), s(subgp_ix: subgp_iy)))
      tea = snorm - t_for_sg * lama2 * pfg 
      IF (tea > 0.0D0) THEN
         s(subgp_ix: subgp_iy) = s(subgp_ix: subgp_iy)* tea / snorm
      ELSE
         s(subgp_ix: subgp_iy) = 0.0D0
      ENDIF
      ENDDO

      
      
      snorm = SQRT(DOT_PRODUCT(s,s))
      tea = snorm - t_for_sg * lama1 * pfg
      IF (tea > 0.0D0) THEN
         b(startix:endix) = s * tea / snorm
         DO k = startix, endix
            b(k) = MIN(MAX(lb, b(k)), ub)
         ENDDO
         
         IF(startix.EQ.1) THEN
            b(1)=s(1)
         ENDIF
         
      ELSE
         b(startix:endix) = 0.0D0
         
         IF(startix.EQ.1) THEN
            b(1)=s(1)
         ENDIF
         
      ENDIF
      
      
      
      
      ALLOCATE(dd(bsg))
      dd = b(startix:endix) - oldb
      IF (ANY(dd .ne. 0.0D0)) THEN
         maxDif = MAX(maxDif, gamg**2 * DOT_PRODUCT(dd,dd))
         r = r - MATMUL(x(:,startix:endix), dd)
         isDifZero = 1
      ENDIF
      DEALLOCATE(s, oldb, dd)
      RETURN
   END SUBROUTINE update_step


   SUBROUTINE strong_kkt_check(is_in_E_set,violation,bn,ix,iy,pf,pfl1,bs,&
         lama1,lama2,lama3,ga,is_in_S_set,x,r,nobs,nvars,vl,drgix,drgiy,cn,cn_s,cn_e,b)
      IMPLICIT NONE
      INTEGER, INTENT(in)::nobs
      INTEGER, INTENT(in)::nvars
      DOUBLE PRECISION,INTENT(in):: x(nobs, nvars)
      DOUBLE PRECISION, INTENT(in):: r(nobs)
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: vl
      INTEGER :: g, startix, endix
      INTEGER, INTENT(in) :: bn
      INTEGER, INTENT(in) ::bs(bn)
      INTEGER, INTENT(in) :: ix(bn), iy(bn)
      INTEGER, DIMENSION(:), INTENT(inout) :: is_in_E_set
      INTEGER, DIMENSION(:), INTENT(in) :: is_in_S_set
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: ga
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: s
      DOUBLE PRECISION :: snorm
      DOUBLE PRECISION, INTENT(in) :: pf(bn)
      DOUBLE PRECISION, INTENT(in) :: pfl1(nvars)
      INTEGER, INTENT(inout) :: violation
      DOUBLE PRECISION, INTENT(in) :: lama1,lama2,lama3
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: theta_tilt
      INTEGER:: startdrg, enddrg, drginx, drgstartinx, drgendinx, theta_tilt_start, theta_tilt_end 
      DOUBLE PRECISION :: theta_drg_norm
      INTEGER:: cn,drginxsub
      INTEGER:: drgix(cn)
      INTEGER:: drgiy(cn)
      INTEGER:: cn_s(bn)
      INTEGER:: cn_e(bn)
      DOUBLE PRECISION, DIMENSION (0:nvars), INTENT(inout) :: b
      
      violation = 0
      DO g = 1, bn
         IF (is_in_S_set(g) .EQ. 1) THEN
            startix = ix(g)
            endix = iy(g)
            
            ALLOCATE(s(bs(g)))
            s = MATMUL(r, x(:,startix:endix)) / nobs
            vl(startix:endix) = s
            CALL hier_block_stat(bs(g), s, pfl1(startix:endix), b(startix:endix), &
                 lama2, lama3, pf(g), cn_s(g), cn_e(g), cn, drgix, drgiy, startix, snorm)
            ga(g) = snorm
            DEALLOCATE(s)
                     
            IF (is_in_E_set(g) .EQ. 1) CYCLE
            IF (ga(g) > pf(g)*lama1) THEN
               is_in_E_set(g) = 1
               violation = 1
            ENDIF
         ENDIF
      ENDDO
      RETURN
   END SUBROUTINE strong_kkt_check

   SUBROUTINE sp_update_step(bsg, startix, endix, b, lama1,lama2,lama3, t_for_sg, pfg, pfl1, x,&
         xidx, xcptr, nnz, isDifZero, nobs, r, gamg, maxDif, nvars, lb, ub, startsubgp, endsubgp, drgix, drgiy,drgdim)

      IMPLICIT NONE
      INTEGER, INTENT(in) :: bsg, nobs, nvars, nnz
      INTEGER, INTENT(in) :: startix, endix
      DOUBLE PRECISION :: gamg
      DOUBLE PRECISION, INTENT(inout) :: maxDif
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: oldb, s, dd
      DOUBLE PRECISION, DIMENSION (0:nvars), INTENT(inout) :: b
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: r
      DOUBLE PRECISION :: snorm, tea
      DOUBLE PRECISION, INTENT(in) :: lama1,lama2,lama3, t_for_sg, pfg, lb, ub
      DOUBLE PRECISION, INTENT(in) :: x(nnz)
      DOUBLE PRECISION, INTENT(in) :: pfl1(bsg)
      INTEGER, INTENT(in) :: xidx(nnz)
      INTEGER, INTENT(in) :: xcptr(nvars + 1)
      INTEGER, INTENT(inout) :: isDifZero
      INTEGER :: k
      INTEGER :: i
      INTEGER :: subgp_ix, subgp_iy
      INTEGER, INTENT(in) :: startsubgp, endsubgp, drgdim
      INTEGER, INTENT(in) :: drgix(drgdim),drgiy(drgdim)
      INTEGER :: s_endinx






      ALLOCATE(s(bsg))
      ALLOCATE(oldb(bsg))
      isDifZero = 0
      s = 0.0D0
      oldb = b(startix:endix)
      ! print *, oldb

      CALL spatx(x, xidx, xcptr, nobs, nvars, nnz, r, s, startix, endix)
      s = s * t_for_sg / nobs + b(startix:endix)
      
      
      s_endinx = endix-startix+1
      CALL softthresh(s(2:s_endinx), lama3*t_for_sg*pfl1(2:bsg), bsg-1)
      
      
      
      DO i = startsubgp, endsubgp
      subgp_ix = drgix(i) - drgix(startsubgp) +2
      subgp_iy = drgiy(i) - drgix(startsubgp) +2
      snorm = SQRT(DOT_PRODUCT(s(subgp_ix: subgp_iy), s(subgp_ix: subgp_iy)))
      tea = snorm - t_for_sg * lama2 * pfg 
      IF (tea > 0.0D0) THEN
         s(subgp_ix: subgp_iy) = s(subgp_ix: subgp_iy)* tea / snorm
      ELSE
         s(subgp_ix: subgp_iy) = 0.0D0
      ENDIF
      ENDDO

      
      
      
      
      
      
      snorm = SQRT(DOT_PRODUCT(s,s))
      tea = snorm - t_for_sg * lama1 * pfg
      IF (tea > 0.0D0) THEN
         b(startix:endix) = s * tea / snorm
         DO k = startix, endix
            b(k) = MIN(MAX(b(k), lb), ub)
         ENDDO
      ELSE
         b(startix:endix) = 0.0D0
      ENDIF
      
      IF(startix.EQ.1) THEN
         b(1)=s(1)
      ENDIF
         
         
      ALLOCATE(dd(bsg))
      dd = b(startix:endix) - oldb
      IF(ANY(dd .ne. 0.0D0)) THEN
         maxDif = MAX(maxDif, gamg**2 * DOT_PRODUCT(dd,dd))
         CALL ymspax(x, xidx, xcptr, nobs, nvars, nnz, dd, r, startix, endix, bsg)
         isDifZero = 1
      ENDIF
      DEALLOCATE(s, oldb, dd)
      RETURN
   END SUBROUTINE sp_update_step


   SUBROUTINE sp_strong_kkt_check(is_in_E_set,violation,bn,ix,iy,pf,pfl1,bs,&
         lama1,lama2,lama3,ga,is_in_S_set,x,xidx,xcptr,nnz,r,nobs,nvars,vl,drgix,drgiy,cn,cn_s,cn_e,b)

      IMPLICIT NONE
      INTEGER, INTENT(in) :: nobs, nvars, nnz
      DOUBLE PRECISION, INTENT(in) :: x(nnz)
      INTEGER, INTENT(in) :: xidx(nnz)
      INTEGER, INTENT(in) :: xcptr(nvars + 1)
      DOUBLE PRECISION, INTENT(in):: r(nobs)
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: vl
      INTEGER :: g, startix, endix
      INTEGER, INTENT(in) :: bn
      INTEGER, INTENT(in) ::bs(bn)
      INTEGER, INTENT(in) :: ix(bn), iy(bn)
      INTEGER, DIMENSION(:), INTENT(inout) :: is_in_E_set
      INTEGER, DIMENSION(:), INTENT(in) :: is_in_S_set
      DOUBLE PRECISION, DIMENSION (:), INTENT(inout) :: ga
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: s
      DOUBLE PRECISION :: snorm
      DOUBLE PRECISION, INTENT(in) :: pf(bn)
      DOUBLE PRECISION, INTENT(in) :: pfl1(nvars)
      INTEGER, INTENT(inout) :: violation
      DOUBLE PRECISION, INTENT(in) :: lama1,lama2,lama3
      
      DOUBLE PRECISION, DIMENSION (:), ALLOCATABLE :: theta_tilt
      INTEGER:: startdrg, enddrg, drginx, drgstartinx, drgendinx, theta_tilt_start, theta_tilt_end
      DOUBLE PRECISION :: theta_drg_norm
      INTEGER:: cn,drginxsub
      INTEGER:: drgix(cn)
      INTEGER:: drgiy(cn)
      INTEGER:: cn_s(bn)
      INTEGER:: cn_e(bn)      
      DOUBLE PRECISION, DIMENSION (0:nvars), INTENT(inout) :: b
      

      violation = 0
      DO g = 1, bn
         IF(is_in_S_set(g) .EQ. 1) THEN
            startix = ix(g)
            endix = iy(g)
            ALLOCATE(s(bs(g)))
            s = 0.0D0
            CALL spatx(x, xidx, xcptr, nobs, nvars, nnz, r, s, startix, endix)
            s = s / nobs
            vl(startix:endix) = s
            CALL hier_block_stat(bs(g), s, pfl1(startix:endix), b(startix:endix), &
                 lama2, lama3, pf(g), cn_s(g), cn_e(g), cn, drgix, drgiy, startix, snorm)
            ga(g) = snorm
            DEALLOCATE(s)
            
            
            IF(is_in_E_set(g) .EQ. 1) CYCLE
            IF(ga(g) > pf(g) * lama1) THEN
               is_in_E_set(g) = 1
               violation = 1
            ENDIF
         ENDIF
      ENDDO
      RETURN
   END SUBROUTINE sp_strong_kkt_check

END MODULE sgl_subfuns


