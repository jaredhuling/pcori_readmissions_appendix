#' @title swjm: Stagewise Variable Selection for Joint Models of Semi-Competing Risks
#'
#' @description
#' Implements stagewise regression for penalized variable selection in joint
#' models of recurrent events and terminal events (semi-competing risks).
#'
#' Two model frameworks are supported:
#' \itemize{
#'   \item \strong{Joint Frailty Model (JFM)}: Cox-type model where
#'     \code{alpha} = recurrence/readmission coefficients (first p elements of theta),
#'     \code{beta} = terminal/death coefficients (second p elements).
#'   \item \strong{Joint Scale-Change Model (JSCM)}: AFT-type model where
#'     \code{alpha} = recurrence/readmission coefficients (first p elements of theta),
#'     \code{beta} = terminal/death coefficients (second p elements).
#' }
#'
#' Three penalty types are available:
#' \itemize{
#'   \item \code{"coop"}: Cooperative lasso, which encourages shared support
#'     between the recurrence and terminal event coefficient vectors.
#'   \item \code{"lasso"}: Standard L1 penalty applied coordinate-wise.
#'   \item \code{"group"}: Group lasso, which selects variables jointly across
#'     both processes.
#' }
#'
#' @section Data Format:
#' All functions expect a recurrent-event data frame with the following columns:
#' \describe{
#'   \item{id}{Subject identifier (integer).}
#'   \item{t.start}{Interval start time.}
#'   \item{t.stop}{Interval stop time.}
#'   \item{event}{1 for recurrent event, 0 for terminal/censoring row.}
#'   \item{status}{1 for death, 0 for alive/censored.}
#'   \item{x1, x2, ..., xp}{Covariate columns.}
#' }
#'
#' @name swjm-package
#' @useDynLib swjm, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom Matrix Diagonal
#' @importFrom stats approx aggregate coef predict
#'   rgamma rnorm rexp rpois runif rweibull
#' @importFrom graphics par matplot lines abline legend text axis mtext barplot
#' @importFrom grDevices adjustcolor
"_PACKAGE"
